# PlaceTrack – Student Placement Dashboard (Module 4, Milestone Project 3)
React 18 + React Router 6 + Context API + Hooks, built with Vite.

## Run
npm install && npm run dev

## Deploy (live link)
Push to GitHub → import the repo on Vercel/Netlify (build: `npm run build`, output: `dist`).
For Netlify add `public/_redirects` containing `/* /index.html 200` so routes work on refresh.

## Features → requirement map
- Student Authentication: Login, Registration, Profile (context.jsx, pages.jsx)
- Placement Opportunities: view, search & filter, apply (Jobs)
- Application Tracking: applied jobs, interview schedule, status (Applications)
- Dashboard Analytics: stats, placement trends, upcoming deadlines (Dashboard)
- Notifications: interview alerts, company updates, announcements
- Technical: components, router, hooks (useFetch), Context API, mock API integration (api.js), responsive CSS, form validation
