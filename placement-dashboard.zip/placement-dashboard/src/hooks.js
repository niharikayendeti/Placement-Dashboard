import { useEffect, useState } from 'react'
// Reusable data hook: handles loading + error states for every API call.
export function useFetch(fn) {
  const [data, setData] = useState(null), [error, setError] = useState(null)
  useEffect(() => { fn().then(setData).catch(() => setError('Could not load data. Refresh to retry.')) }, [])
  return { data, error, loading: !data && !error }
}
