import { createContext, useContext, useState, useEffect } from 'react'
const Ctx = createContext()
export const useApp = () => useContext(Ctx)
const load = (k, d) => { try { return JSON.parse(localStorage.getItem(k)) ?? d } catch { return d } }

export function Provider({ children }) {
  const [users, setUsers] = useState(() => load('pt_users', []))
  const [user, setUser] = useState(() => load('pt_user', null))
  const [applied, setApplied] = useState(() => load('pt_applied', {}))
  useEffect(() => localStorage.setItem('pt_users', JSON.stringify(users)), [users])
  useEffect(() => localStorage.setItem('pt_user', JSON.stringify(user)), [user])
  useEffect(() => localStorage.setItem('pt_applied', JSON.stringify(applied)), [applied])

  const register = u => {
    if (users.some(x => x.email === u.email)) return 'Email already registered. Log in instead.'
    setUsers([...users, u]); setUser(u); return null }
  const login = (email, password) => {
    const u = users.find(x => x.email === email && x.password === password)
    if (!u) return 'Email or password is incorrect.'
    setUser(u); return null }
  const logout = () => setUser(null)
  const updateProfile = p => {
    const u = { ...user, ...p }
    setUser(u); setUsers(users.map(x => x.email === u.email ? u : x)) }
  const apply = id => setApplied({ ...applied, [id]: 'Applied' })
  const setStatus = (id, s) => setApplied({ ...applied, [id]: s })

  return <Ctx.Provider value={{ user, register, login, logout, updateProfile, applied, apply, setStatus }}>
    {children}</Ctx.Provider>
}
