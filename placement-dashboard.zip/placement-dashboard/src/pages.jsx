import { useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { useApp } from './context'
import { useFetch } from './hooks'
import { getJobs, getTrends, getAnnouncements, getInterviews } from './api'

const Load = ({ s, children }) => s.error ? <p className="err">{s.error}</p>
  : s.loading ? <p className="muted">Loading…</p> : children

function Field({ label, error, ...p }) {
  return <label>{label}<input {...p} />{error && <small className="err">{error}</small>}</label>
}

/* ---------- Auth ---------- */
const emailOk = e => /^\S+@\S+\.\S+$/.test(e)
function AuthForm({ mode }) {
  const { login, register } = useApp(), nav = useNavigate()
  const [f, setF] = useState({ name: '', email: '', password: '', branch: 'AI & ML', cgpa: '' })
  const [errs, setErrs] = useState({}), [msg, setMsg] = useState('')
  const set = k => e => setF({ ...f, [k]: e.target.value })
  const submit = e => {
    e.preventDefault()
    const er = {}
    if (mode === 'register' && f.name.trim().length < 3) er.name = 'Enter your full name.'
    if (!emailOk(f.email)) er.email = 'Enter a valid email address.'
    if (f.password.length < 6) er.password = 'Use at least 6 characters.'
    if (mode === 'register' && !(f.cgpa >= 0 && f.cgpa <= 10 && f.cgpa !== '')) er.cgpa = 'CGPA must be 0–10.'
    setErrs(er); if (Object.keys(er).length) return
    const r = mode === 'login' ? login(f.email, f.password) : register(f)
    r ? setMsg(r) : nav('/')
  }
  return (<div className="auth"><form onSubmit={submit} noValidate>
    <h2>{mode === 'login' ? 'Log in to PlaceTrack' : 'Create your student account'}</h2>
    {mode === 'register' && <Field label="Full name" value={f.name} onChange={set('name')} error={errs.name} />}
    <Field label="College email" type="email" value={f.email} onChange={set('email')} error={errs.email} />
    <Field label="Password" type="password" value={f.password} onChange={set('password')} error={errs.password} />
    {mode === 'register' && <Field label="CGPA" type="number" step="0.01" value={f.cgpa} onChange={set('cgpa')} error={errs.cgpa} />}
    {msg && <p className="err">{msg}</p>}
    <button className="primary">{mode === 'login' ? 'Log in' : 'Create account'}</button>
    <p className="muted">{mode === 'login' ? <>New here? <Link to="/register">Create an account</Link></>
      : <>Already registered? <Link to="/login">Log in</Link></>}</p>
  </form></div>)
}
export const Login = () => <AuthForm mode="login" />
export const Register = () => <AuthForm mode="register" />

/* ---------- Dashboard ---------- */
export function Dashboard() {
  const { applied, user } = useApp()
  const jobs = useFetch(getJobs), trends = useFetch(getTrends)
  const vals = Object.values(applied)
  const count = s => vals.filter(v => v === s).length
  const soon = jobs.data && [...jobs.data].sort((a, b) => a.deadline.localeCompare(b.deadline)).slice(0, 3)
  return (<>
    <h2>Welcome back, {user.name.split(' ')[0]}</h2>
    <section className="stats">
      {[['Applied', vals.length], ['Interviews', count('Interview')], ['Selected', count('Selected')], ['Rejected', count('Rejected')]]
        .map(([l, n]) => <div key={l} className="stat"><b>{n}</b>{l}</div>)}
    </section>
    <section className="panel"><h3>Placement rate by year (%)</h3>
      <Load s={trends}><div className="bars">{trends.data?.map(t =>
        <div key={t.year} className="bar" style={{ '--h': t.placed + '%' }}><span>{t.placed}</span><i>{t.year}</i></div>)}</div></Load></section>
    <section className="panel"><h3>Upcoming deadlines</h3>
      <Load s={jobs}><ul className="list">{soon?.map(j =>
        <li key={j.id}><span>{j.company} – {j.role}</span><em>{j.deadline}</em></li>)}</ul></Load></section>
  </>)
}

/* ---------- Openings ---------- */
export function Jobs() {
  const s = useFetch(getJobs), { applied, apply } = useApp()
  const [q, setQ] = useState(''), [type, setType] = useState('All')
  const list = s.data?.filter(j => (type === 'All' || j.type === type) &&
    (j.company + j.role).toLowerCase().includes(q.toLowerCase()))
  return (<>
    <h2>Job openings</h2>
    <div className="filters">
      <input placeholder="Search company or role" value={q} onChange={e => setQ(e.target.value)} />
      <select value={type} onChange={e => setType(e.target.value)}>
        {['All', 'Software', 'AI/ML', 'Data'].map(t => <option key={t}>{t}</option>)}</select></div>
    <Load s={s}>{list?.length === 0 && <p className="muted">No openings match. Clear the filters to see all.</p>}
      <div className="grid">{list?.map(j => (<article key={j.id} className="card">
        <h3>{j.company}</h3><p>{j.role}</p><p className="muted">{j.type} · {j.pkg} · apply by {j.deadline}</p>
        <button className="primary" disabled={applied[j.id]} onClick={() => apply(j.id)}>
          {applied[j.id] ? 'Applied' : 'Apply now'}</button></article>))}</div></Load>
  </>)
}

/* ---------- Applications ---------- */
export function Applications() {
  const jobs = useFetch(getJobs), iv = useFetch(getInterviews), { applied, setStatus } = useApp()
  const mine = jobs.data?.filter(j => applied[j.id])
  return (<>
    <h2>My applications</h2>
    <Load s={jobs}>{mine?.length === 0 && <p className="muted">Nothing applied yet. <Link to="/jobs">Browse openings</Link></p>}
      <ul className="list">{mine?.map(j => (<li key={j.id}><span>{j.company} – {j.role}</span>
        <select value={applied[j.id]} onChange={e => setStatus(j.id, e.target.value)}>
          {['Applied', 'Interview', 'Selected', 'Rejected'].map(s => <option key={s}>{s}</option>)}</select></li>))}</ul></Load>
    <h3>Interview schedule</h3>
    <Load s={iv}><ul className="list">{iv.data?.map(i =>
      <li key={i.id}><span>{i.company} · {i.mode}</span><em>{i.date}, {i.time}</em></li>)}</ul></Load>
  </>)
}

/* ---------- Notifications ---------- */
export function Notifications() {
  const s = useFetch(getAnnouncements)
  return (<><h2>Notifications</h2><Load s={s}><ul className="list">
    {s.data?.map(n => <li key={n.id}><span>{n.text}</span><em>{n.kind}</em></li>)}</ul></Load></>)
}

/* ---------- Profile ---------- */
export function Profile() {
  const { user, updateProfile } = useApp()
  const [f, setF] = useState({ name: user.name, branch: user.branch, cgpa: user.cgpa })
  const [saved, setSaved] = useState(false)
  const save = e => { e.preventDefault(); updateProfile(f); setSaved(true) }
  return (<><h2>Profile</h2><form className="panel" onSubmit={save}>
    <Field label="Full name" value={f.name} onChange={e => setF({ ...f, name: e.target.value })} />
    <Field label="Branch" value={f.branch} onChange={e => setF({ ...f, branch: e.target.value })} />
    <Field label="CGPA" type="number" step="0.01" value={f.cgpa} onChange={e => setF({ ...f, cgpa: e.target.value })} />
    <button className="primary">Save changes</button>{saved && <p className="muted">Changes saved.</p>}</form></>)
}
