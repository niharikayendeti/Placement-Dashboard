import { NavLink, Navigate, Route, Routes } from 'react-router-dom'
import { useApp } from './context'
import { Login, Register, Dashboard, Jobs, Applications, Notifications, Profile } from './pages'

const Guard = ({ children }) => useApp().user ? children : <Navigate to="/login" replace />

function Shell({ children }) {
  const { user, logout } = useApp()
  const links = [['/', 'Dashboard'], ['/jobs', 'Openings'], ['/applications', 'My applications'],
                 ['/notifications', 'Notifications'], ['/profile', 'Profile']]
  return (<div className="shell">
    <aside><h1>PlaceTrack</h1>
      <nav>{links.map(([to, t]) => <NavLink key={to} to={to} end={to === '/'}>{t}</NavLink>)}</nav>
      <div className="who">{user.name}<button onClick={logout}>Log out</button></div></aside>
    <main>{children}</main></div>)
}

export default function App() {
  const page = el => <Guard><Shell>{el}</Shell></Guard>
  return (<Routes>
    <Route path="/login" element={<Login />} />
    <Route path="/register" element={<Register />} />
    <Route path="/" element={page(<Dashboard />)} />
    <Route path="/jobs" element={page(<Jobs />)} />
    <Route path="/applications" element={page(<Applications />)} />
    <Route path="/notifications" element={page(<Notifications />)} />
    <Route path="/profile" element={page(<Profile />)} />
    <Route path="*" element={<Navigate to="/" />} />
  </Routes>)
}
