// Mock API: swap these functions for fetch('https://your-backend/...') later.
const wait = (v, ms = 500) => new Promise(r => setTimeout(() => r(v), ms))
const JOBS = [
 {id:1,company:'Infosys',role:'Systems Engineer',type:'Software',pkg:'6.5 LPA',deadline:'2026-10-20'},
 {id:2,company:'TCS',role:'Digital Associate',type:'Software',pkg:'7 LPA',deadline:'2026-10-25'},
 {id:3,company:'Zoho',role:'ML Engineer',type:'AI/ML',pkg:'10 LPA',deadline:'2026-10-18'},
 {id:4,company:'Accenture',role:'Data Analyst',type:'Data',pkg:'8 LPA',deadline:'2026-11-02'},
 {id:5,company:'Wipro',role:'Project Engineer',type:'Software',pkg:'6 LPA',deadline:'2026-11-10'},
 {id:6,company:'Fractal',role:'AI Associate',type:'AI/ML',pkg:'12 LPA',deadline:'2026-10-30'}]
export const getJobs = () => wait(JOBS)
export const getTrends = () => wait([
 {year:'2021',placed:62},{year:'2022',placed:70},{year:'2023',placed:76},
 {year:'2024',placed:81},{year:'2025',placed:88}])
export const getAnnouncements = () => wait([
 {id:1,kind:'Interview',text:'Zoho interview: 22 Oct, 10:00 AM, Seminar Hall'},
 {id:2,kind:'Company',text:'Fractal opened 20 new AI Associate seats'},
 {id:3,kind:'Placement',text:'Aptitude training starts Monday for all final-year students'}])
export const getInterviews = () => wait([
 {id:1,company:'Zoho',date:'2026-10-22',time:'10:00 AM',mode:'On campus'},
 {id:2,company:'Infosys',date:'2026-10-27',time:'2:30 PM',mode:'Online'}],300)
